import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setNavScrolled } from './store/slices/uiSlice';
import { SITE_CONFIG } from './config/siteConfig';
import HomePage from './public/pages/HomePage';
import RegisterDetailsPage from './public/pages/RegisterDetailsPage';
import LoginPage from './member/pages/LoginPage';
import AdminLoginPage from './admin/pages/AdminLoginPage';
import TermsPage from './public/pages/TermsPage';
import PrivacyPolicyPage from './public/pages/PrivacyPolicyPage';
import RefundPolicyPage from './public/pages/RefundPolicyPage';
import ContactPage from './public/pages/ContactPage';
import MemberDashboard from './member/pages/MemberDashboard';
import MemberHome from './member/components/MemberPanel/MemberHome';
import CommissionSetup from './member/components/MemberPanel/Commission/CommissionSetup';
import AEPSReport from './member/components/MemberPanel/Reports/AEPSReport';
import DMTHistory from './member/components/MemberPanel/Reports/DMTHistory';
import PayoutHistory from './member/components/MemberPanel/Reports/PayoutHistory';
import MATMHistory from './member/components/MemberPanel/Reports/MATMHistory';
import RechargeHistory from './member/components/MemberPanel/Reports/RechargeHistory';
import BBPSHistory from './member/components/MemberPanel/Reports/BBPSHistory';
import BusinessSummary from './member/components/MemberPanel/Reports/BusinessSummary';
import AEPSWalletHistory from './member/components/MemberPanel/Reports/AEPSWalletHistory';
import MainWalletHistory from './member/components/MemberPanel/Reports/MainWalletHistory';
import WalletToWallet from './member/components/MemberPanel/Wallet/WalletToWallet';
import FundRequest from './member/components/MemberPanel/Wallet/FundRequest';
import MyServices from './member/components/MemberPanel/MyServices';
import UploadKYC from './member/components/MemberPanel/KYC/UploadKYC';
import MyProfile from './member/components/MemberPanel/Profile/MyProfile';
import DashboardPage from './admin/pages/DashboardPage';
import MobilePostpaid from './member/components/MemberPanel/Services/MobilePostpaid';
import DTHRecharge from './member/components/MemberPanel/Services/DTHRecharge';
import Electricity from './member/components/MemberPanel/Services/Electricity';
import Water from './member/components/MemberPanel/Services/Water';
import Gas from './member/components/MemberPanel/Services/Gas';
import LPGGas from './member/components/MemberPanel/Services/LPGGas';
import Insurance from './member/components/MemberPanel/Services/Insurance';
import Landline from './member/components/MemberPanel/Services/Landline';
import Fastag from './member/components/MemberPanel/Services/Fastag';
import CableTV from './member/components/MemberPanel/Services/CableTV';
import MunicipalTax from './member/components/MemberPanel/Services/MunicipalTax';
import MobileRecharge from './member/components/MemberPanel/Services/MobileRecharge';
import MemberCertificate from './member/components/MemberPanel/Certificate/MemberCertificate';
import DMT from './member/components/MemberPanel/Services/DMT';
import Payout from './member/components/MemberPanel/Services/Payout';
import AadharPay from './member/components/MemberPanel/Services/AadharPay';
import Aeps from './member/components/MemberPanel/Services/Aeps';
import UpiCashout from './member/components/MemberPanel/Services/UpiCashout';
import UpiTransfer from './member/components/MemberPanel/Services/UpiTransfer';
import PanCard from './member/components/MemberPanel/Services/PanCard';

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    // Dynamic page title and description
    document.title = SITE_CONFIG.brandName;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', `${SITE_CONFIG.companyName} - Complete digital platform for mobile & DTH recharge, bill payments, payout, and other financial services.`);
    }

    const handleScroll = () => dispatch(setNavScrolled(window.scrollY > 50));
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [dispatch]);

  return (
    <div className="App">
      <Routes>
          {/* --- PUBLIC ROUTES --- */}
          <Route path="/" element={<HomePage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPolicyPage />} />
          <Route path="/refund" element={<RefundPolicyPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/register" element={<RegisterDetailsPage />} />
          <Route path="/register/details" element={<Navigate to="/register" replace />} />
          <Route path="/login" element={<Navigate to="/member/login" replace />} />

          {/* --- MEMBER ROUTES --- */}
          <Route path="/member/login" element={<LoginPage />} />
          <Route path="/member/dashboard" element={<MemberDashboard />}>
            <Route index element={<MemberHome />} />
            <Route path="profile" element={<MyProfile />} />
            <Route path="commission" element={<CommissionSetup />} />
            <Route path="report/aeps" element={<AEPSReport />} />
            <Route path="report/dmt" element={<DMTHistory />} />
            <Route path="report/payout" element={<PayoutHistory />} />
            <Route path="report/matm" element={<MATMHistory />} />
            <Route path="report/recharge" element={<RechargeHistory />} />
            <Route path="report/bbps" element={<BBPSHistory />} />
            <Route path="report/business" element={<BusinessSummary />} />
            <Route path="wallet/aeps" element={<AEPSWalletHistory />} />
            <Route path="wallet/main" element={<MainWalletHistory />} />
            <Route path="wallet/w2w" element={<WalletToWallet />} />
            <Route path="wallet/fund-request" element={<FundRequest />} />
            <Route path="my-services" element={<MyServices />} />
            <Route path="kyc/upload" element={<UploadKYC />} />
            <Route path="service/mobile-postpaid" element={<MobilePostpaid />} />
            <Route path="service/dth" element={<DTHRecharge />} />
            <Route path="service/electricity" element={<Electricity />} />
            <Route path="service/water" element={<Water />} />
            <Route path="service/gas" element={<Gas />} />
            <Route path="service/lpg" element={<LPGGas />} />
            <Route path="service/insurance" element={<Insurance />} />
            <Route path="service/landline" element={<Landline />} />
            <Route path="service/fastag" element={<Fastag />} />
            <Route path="service/cable-tv" element={<CableTV />} />
            <Route path="service/municipal-tax" element={<MunicipalTax />} />
            <Route path="service/mobile-recharge" element={<MobileRecharge />} />
            <Route path="service/dmt" element={<DMT />} />
            <Route path="service/payout" element={<Payout />} />
            <Route path="service/aadharpay" element={<AadharPay />} />
            <Route path="service/aeps" element={<Aeps />} />
            <Route path="service/upicashout" element={<UpiCashout />} />
            <Route path="service/upitransfer" element={<UpiTransfer />} />
            <Route path="service/pan" element={<PanCard />} />
            <Route path="certificate" element={<MemberCertificate />} />
          </Route>
          <Route path="/member/commission" element={<Navigate to="/member/dashboard/commission" replace />} />
          <Route path="/member/report/aeps" element={<Navigate to="/member/dashboard/report/aeps" replace />} />
          <Route path="/member/kyc/upload" element={<Navigate to="/member/dashboard/kyc/upload" replace />} />
          <Route path="/member/certificate" element={<Navigate to="/member/dashboard/certificate" replace />} />

          {/* --- ADMIN ROUTES --- */}
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/admin/dashboard" element={<DashboardPage />} />
          <Route path="/admin/dashboard/:tab" element={<DashboardPage />} />
          <Route path="/dashboard" element={<Navigate to="/admin/dashboard" replace />} />
        </Routes>
      </div>
  );
}

export default App;
