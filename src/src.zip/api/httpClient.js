// Secure Axios Client
import axios from 'axios';
import { requestInterceptor, responseInterceptor } from './interceptors';

const httpClient = axios.create({
    baseURL: 'https://api.sahayatamoney.in/api',
    headers: { 'Content-Type': 'application/json' }
});

httpClient.interceptors.request.use(requestInterceptor);
httpClient.interceptors.response.use(responseInterceptor);

export default httpClient;