// JWT/refresh + Encryption
export const requestInterceptor = async (config) => {
    const token = localStorage.getItem('access_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;

    // Security Context (IP, Loc, Device)
    const ipRes = await fetch('https://api.ipify.org?format=json').catch(() => ({ ip: '0.0.0.0' }));
    const { ip } = await ipRes.json();
    
    // Header mein inject karo
    config.headers['X-Device-Info'] = navigator.userAgent;
    config.headers['X-IP'] = ip;
    
    return config;
};

export const responseInterceptor = (response) => response;