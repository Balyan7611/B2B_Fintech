// API Endpoints
import httpClient from './httpClient';

// Login Request Model (Validation logic here)
const LoginMapper = (data, security) => ({
    loginID: data.loginID,
    password: data.password,
    ip: security.ip,
    deviceInfo: { browser: navigator.userAgent, os: navigator.platform },
    location: { latitude: 0, longitude: 0, accuracy: 0 }
});

export const API = {
    login: async (payload) => {
        // Ye security context yahan fetch kar sakte ho ya interceptor mein
        const response = await httpClient.post('/UserAuth/LoginUser', payload);
        return response.data;
    },
    // Aise hi add karte ja
};