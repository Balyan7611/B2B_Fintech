// Device ID generation
