// Secure JWT storage
