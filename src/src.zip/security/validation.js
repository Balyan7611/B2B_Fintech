// Input validation
