// Anti-CSRF token handler
