// VPN Detector Util
