// Secure Input Component
