// Centralized Brand and Contact Configuration
export const SITE_CONFIG = {
  companyName: 'BETASOURCESOFTWARE PVT LTD',
  brandName: 'BETA SOURCE SOFTWARE',
  shortName: 'BETASOURCE',
  ownerName: 'Surender Maharwar',
  phone: '9351051856',
  email: 'sales@betasourcesoftware.com',
  address: 'Jaipur, Rajasthan',
  logo: '/images/header_logo.png',
  description: 'BETASOURCESOFTWARE PVT LTD is a trusted digital platform providing Recharge, BBPS, Credit Card Bill Payment, Payment Gateway, Payout, and MATM services.'
};
