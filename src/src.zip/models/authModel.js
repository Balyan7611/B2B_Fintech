export const LoginRequestModel = (data, security) => {
    // 100% Validation
    if (!data.loginID) throw new Error("Login ID is missing!");
    if (!data.password || data.password.length < 6) throw new Error("Password too short!");

    return {
        ip: security.ip,
        loginID: data.loginID,
        password: data.password,
        deviceInfo: security.deviceInfo,
        location: security.location
    };
};

export const LoginResponseModel = (response) => {
    if (response.status !== true) throw new Error(response.mess || "Login Failed");
    return response.data; 
};