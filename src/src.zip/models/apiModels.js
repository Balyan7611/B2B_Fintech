// Request Models (Payloads)
export const LoginRequest = (loginID, password, securityData) => ({
    loginID,
    password,
    ip: securityData.ip,
    deviceInfo: securityData.deviceInfo,
    location: securityData.location
});

// Response Model (Validation)
export const LoginResponse = (data) => ({
    code: data.code,
    status: data.status,
    message: data.mess,
    accessToken: data.data?.accessToken || "",
    refreshToken: data.data?.refreshToken || ""
});