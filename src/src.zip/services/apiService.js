import axios from 'axios';

const api = axios.create({
    baseURL: 'https://api.sahayatamoney.in/api',
    headers: { 'Content-Type': 'application/json' }
});

// Security & Auth Interceptor
api.interceptors.request.use(async (config) => {
    const token = localStorage.getItem('access_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    
    config.headers['X-Device-Info'] = navigator.userAgent;
    config.headers['X-Platform'] = navigator.platform;
    return config;
});

// Security Context Generator
const getSecurityContext = async () => {
    const ipRes = await fetch('https://api.ipify.org?format=json').catch(() => ({ ip: '0.0.0.0' }));
    const { ip } = await ipRes.json();
    const pos = await new Promise((res) => navigator.geolocation.getCurrentPosition(res, () => res({ coords: { latitude: 0, longitude: 0, accuracy: 0 } })));
    
    return {
        ip,
        deviceInfo: {
            browser: navigator.userAgent,
            os: navigator.platform,
            device: 'Web',
            userAgent: navigator.userAgent
        },
        location: {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy
        }
    };
};

export const apiService = {
    async get(url, params = {}) {
        const response = await api.get(url, { params });
        return response.data;
    },
    async post(url, data, ModelMapper) {
        const security = await getSecurityContext();
        const payload = ModelMapper ? ModelMapper(data, security) : { ...data, ...security };
        const response = await api.post(url, payload);
        return response.data;
    },
    async put(url, data, ModelMapper) {
        const security = await getSecurityContext();
        const payload = ModelMapper ? ModelMapper(data, security) : { ...data, ...security };
        const response = await api.put(url, payload);
        return response.data;
    },
    async delete(url) {
        const response = await api.delete(url);
        return response.data;
    }
};