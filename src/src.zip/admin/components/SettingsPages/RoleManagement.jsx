import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  FiSearch, FiEdit, FiTrash2, FiPlus, FiChevronLeft, FiChevronRight, FiDatabase, FiX, FiCheck, FiUsers, FiTag, FiHash, FiDollarSign, FiCode, FiList
} from 'react-icons/fi';
import {
  FaFileExcel, FaFilePdf, FaFileCsv, FaCopy, FaPrint
} from 'react-icons/fa';
import styles from '../MemberPages/MemberPages.module.css';

const RoleManagement = () => {
  const dispatch = useDispatch();
  const { roles = [] } = useSelector(state => state.settings || {});
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [showConfirmModal, setShowConfirmModal] = useState({ isOpen: false, id: null });

  const [localRoles, setLocalRoles] = useState([
    { id: 1, name: 'Admin', prefix: 'ADMIN', startId: 1, price: '0.00', status: true, regCount: 100000, addDate: '27/03/2025' },
    { id: 2, name: 'White Label', prefix: 'WL', startId: 3659, price: '0.00', status: true, regCount: 6, addDate: '27/03/2025' },
    { id: 3, name: 'Master Distributor', prefix: 'MDT', startId: 8596, price: '0.00', status: true, regCount: 6, addDate: '27/03/2025' },
    { id: 4, name: 'Distributor', prefix: 'PAY99DT', startId: 5000, price: '0.00', status: true, regCount: 1000, addDate: '27/03/2025' },
  ]);

  const [formData, setFormData] = useState({
    name: '', prefix: '', type: '', startId: '', regCount: '', outside: false, status: true, price: '0', redirectUrl: ''
  });

  // State to manage hovered role services popover
  const [hoveredRole, setHoveredRole] = useState(null);
  const [popoverPos, setPopoverPos] = useState({ x: 0, y: 0, placement: 'bottom' });

  // Map of mock assigned services per role
  const getAssignedServices = (roleName) => {
    const roleLower = roleName?.toLowerCase() || '';
    if (roleLower === 'retailer') {
      return ['Mobile Prepaid', 'DTH Recharge', 'AEPS Cash Withdrawal', 'Aadhar Pay', 'Money Transfer (DMT)', 'Utility Bill Payment (BBPS)'];
    } else if (roleLower === 'distributor') {
      return ['Mobile Prepaid', 'DTH Recharge', 'AEPS Cash Withdrawal', 'Aadhar Pay', 'Money Transfer (DMT)', 'Utility Bill Payment (BBPS)', 'Fastag Recharge', 'Pan Card', 'Broadband Postpaid'];
    } else if (roleLower === 'master distributor' || roleLower === 'master') {
      return ['Mobile Prepaid', 'DTH Recharge', 'AEPS Cash Withdrawal', 'Aadhar Pay', 'Money Transfer (DMT)', 'Utility Bill Payment (BBPS)', 'Fastag Recharge', 'Pan Card', 'Broadband Postpaid', 'Insurance Premium', 'LPG Gas Booking'];
    } else if (roleLower === 'admin') {
      return ['All 57 Services Active', 'Gateway Direct API', 'Fund Settlement', 'Full System Access', 'Role Creation', 'News Broadcast', 'System Configuration'];
    } else {
      // Default or others (e.g. White Label)
      return ['Mobile Prepaid', 'DTH Recharge', 'AEPS Cash Withdrawal', 'Utility Bill Payment (BBPS)', 'Aadhar Pay', 'Money Transfer (DMT)', 'Pan Card API'];
    }
  };

  const handleDelete = () => {
    setLocalRoles(localRoles.filter(r => r.id !== showConfirmModal.id));
    setShowConfirmModal({ isOpen: false, id: null });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddClick = () => {
    setFormData({ name: '', prefix: '', type: '', startId: '', regCount: '', outside: false, status: true, price: '0', redirectUrl: '' });
    setIsModalOpen(true);
  };

  const handleEdit = (role) => {
    setFormData({ ...formData, ...role });
    setIsModalOpen(true);
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (formData.id) {
      setLocalRoles(localRoles.map(r => r.id === formData.id ? { ...r, ...formData } : r));
    } else {
      const newRole = { ...formData, id: Date.now(), addDate: new Date().toLocaleDateString('en-GB') };
      setLocalRoles([...localRoles, newRole]);
    }
    setIsModalOpen(false);
  };

  // Hover Popover handlers
  const handleMouseEnter = (e, role) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setPopoverPos({
      x: rect.right + 15,
      y: rect.top + window.scrollY + (rect.height / 2) - 100,
      placement: 'right'
    });
    setHoveredRole(role);
  };

  const handleMouseLeave = () => {
    setHoveredRole(null);
  };

  return (
    <div className={styles.container} style={{ padding: '5px 2px 0px 2px', maxWidth: '100%' }}>
      {/* ── MAIN REPOSITORY CARD ── */}
      <div className={styles.cardFullMobile} style={{ margin: '8px 8px 15px 8px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', background: '#fff', borderRadius: '16px' }}>
        {/* CARD INTERNAL HEADER */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 20px', borderBottom: '1px solid #F1F5F9', flexWrap: 'nowrap', gap: '10px' }}>
          <h3 style={{ margin: 0, fontSize: '1.15rem', fontWeight: 800, color: '#0F172A' }}>System Roles</h3>
          <button style={{
            display: 'flex', alignItems: 'center', gap: '8px',
            background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
            color: '#fff', border: 'none', borderRadius: '8px',
            padding: '10px 20px', fontSize: '0.85rem', fontWeight: 700,
            cursor: 'pointer', boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)', transition: 'all 0.2s'
          }} onClick={handleAddClick}>
            <FiPlus size={16} /> <span>Add New Role</span>
          </button>
        </div>

        {/* ── TOOLBAR ── */}
        <div className="global-table-toolbar" style={{ padding: '10px 15px', flexWrap: 'wrap', gap: '15px', borderBottom: 'none' }}>
          <div className={styles.pillRow} style={{ alignItems: 'center' }}>
            <span style={{ fontSize: '0.85rem', color: '#4E6080', fontWeight: 600 }}>Show</span>
            <select className={styles.selectEntries} style={{ borderRadius: '8px', border: '1px solid #E2E8F0' }}>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
            </select>
            <span style={{ fontSize: '0.85rem', color: '#4E6080', fontWeight: 600 }}>entries</span>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', justifyContent: 'center', flex: 1 }}>
            <button className="global-export-btn btn-copy" title="Copy Table"><FaCopy /></button>
            <button className="global-export-btn btn-excel" title="Download Excel"><FaFileExcel /></button>
            <button className="global-export-btn btn-pdf" title="Download PDF"><FaFilePdf /></button>
            <button className="global-export-btn btn-csv" title="Download CSV"><FaFileCsv /></button>
            <button className="global-export-btn btn-print" title="Print Table"><FaPrint /></button>
          </div>

          <div className="global-search-box" style={{ maxWidth: '300px' }}>
            <FiSearch />
            <input
              type="text"
              placeholder="Search roles..."
              style={{ borderRadius: '10px' }}
            />
          </div>
        </div>

        {/* ── TABLE ── */}
        <div className={styles.tableWrapper}>
          <table className={styles.table} style={{ width: '100%', minWidth: '950px', tableLayout: 'auto' }}>
            <thead>
              <tr style={{ background: 'linear-gradient(90deg, #0D1B5E 0%, #1a2f8a 100%)' }}>
                <th style={{ width: '50px' }}>S.NO</th>
                <th style={{ width: '90px', textAlign: 'center' }}>ACTION</th>
                <th style={{ width: '300px' }}>ROLE IDENTITY</th>
                <th style={{ width: '120px', textAlign: 'left' }}>PREFIX</th>
                <th style={{ width: '120px', textAlign: 'left' }}>START ID</th>
                <th style={{ width: '120px', textAlign: 'left' }}>PRICE (₹)</th>
                <th style={{ width: '120px', textAlign: 'left' }}>STATUS</th>
                <th style={{ width: '150px', textAlign: 'left' }}>ADD DATE</th>
              </tr>
            </thead>
            <tbody>
              {localRoles.map((role, idx) => (
                <tr key={role.id} className={styles.hoverRow}>
                  <td style={{ fontWeight: 700, color: '#A0AEC0' }}>{idx + 1}</td>
                  <td style={{ textAlign: 'center' }}>
                    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                      <button className={styles.editBtn} style={{ width: '32px', height: '32px', borderRadius: '8px', background: '#F8FAFC', color: '#3B82F6', border: '1px solid #E2E8F0', cursor: 'pointer' }} onClick={() => handleEdit(role)} title="Edit Role"><FiEdit /></button>
                      <button className={styles.deleteBtn} style={{ width: '32px', height: '32px', borderRadius: '8px', background: '#FFF5F5', color: '#E53E3E', border: '1px solid #FED7D7', cursor: 'pointer' }} title="Delete Role" onClick={() => setShowConfirmModal({ isOpen: true, id: role.id })}><FiTrash2 /></button>
                    </div>
                  </td>
                  
                  {/* HOVER TARGET CELL (ROLE IDENTITY) */}
                  <td style={{ cursor: 'pointer' }}>
                    <div 
                      onMouseEnter={(e) => handleMouseEnter(e, role)}
                      onMouseLeave={handleMouseLeave}
                      style={{ display: 'flex', alignItems: 'center', gap: '12px', width: 'fit-content' }}
                    >
                      <div style={{ width: '36px', height: '36px', background: 'rgba(23, 86, 170, 0.05)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#1756AA' }}>
                        <FiUsers />
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ color: '#1756AA', fontSize: '0.95rem', fontWeight: 800, borderBottom: '1px dashed #1756AA' }}>
                          {role.name}
                        </span>
                        <small style={{ color: '#718096', fontWeight: 600 }}>Reg. Count: {role.regCount}</small>
                      </div>
                    </div>
                  </td>
                  
                  <td style={{ textAlign: 'left' }}>
                    <span style={{ background: 'rgba(23, 86, 170, 0.1)', color: '#1756AA', padding: '4px 12px', borderRadius: '6px', fontSize: '0.75rem', fontWeight: 800 }}>
                      {role.prefix}
                    </span>
                  </td>
                  <td style={{ textAlign: 'left', fontWeight: 700, color: '#4E6080' }}>{role.startId}</td>
                  <td style={{ textAlign: 'left', fontWeight: 800, color: '#27AE60' }}>{role.price}</td>
                  <td style={{ textAlign: 'left' }}>
                    <div style={{ fontSize: '0.75rem', fontWeight: 800, color: role.status ? '#27AE60' : '#E53E3E', background: role.status ? 'rgba(39, 174, 96, 0.1)' : 'rgba(229, 62, 62, 0.1)', padding: '5px 12px', borderRadius: '50px', display: 'inline-block' }}>
                      ● {role.status ? 'ACTIVE' : 'INACTIVE'}
                    </div>
                  </td>
                  <td style={{ textAlign: 'left', color: '#718096', fontWeight: 700, fontSize: '0.85rem' }}>{role.addDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* ── PAGINATION ── */}
        <div className="global-pagination" style={{ padding: '25px', borderTop: '1px solid #F1F5F9' }}>
          <div style={{ fontSize: '0.85rem', color: '#718096', fontWeight: 600 }}>
            Showing 1 to {localRoles.length} of {localRoles.length} records
          </div>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <button className="global-page-btn" disabled style={{ borderRadius: '8px' }}><FiChevronLeft /></button>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '35px', height: '35px', background: '#1756AA', color: 'white', borderRadius: '8px', fontWeight: 700, fontSize: '0.9rem' }}>1</div>
            <button className="global-page-btn" disabled style={{ borderRadius: '8px' }}><FiChevronRight /></button>
          </div>
        </div>
      </div>

      {/* ── ASSIGNED SERVICES FLOATING POPOVER ── */}
      {hoveredRole && (
        <div style={{
          position: 'absolute',
          top: popoverPos.y,
          left: popoverPos.x,
          background: '#ffffff',
          border: '1px solid #CBD5E1',
          borderRadius: '12px',
          padding: '16px',
          boxShadow: '0 12px 30px rgba(15, 23, 42, 0.15)',
          zIndex: 9999,
          width: '320px',
          pointerEvents: 'none',
          animation: 'fadeIn 0.15s ease-out'
        }}>
          {/* Arrow */}
          <div style={{
            position: 'absolute',
            left: '-6px',
            top: 'calc(50% - 5px)',
            width: '10px',
            height: '10px',
            background: '#ffffff',
            borderLeft: '1px solid #CBD5E1',
            borderBottom: '1px solid #CBD5E1',
            transform: 'rotate(45deg)'
          }} />
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px', borderBottom: '1px solid #F1F5F9', paddingBottom: '6px' }}>
            <FiList style={{ color: '#1756AA', fontSize: '1rem' }} />
            <h4 style={{ margin: 0, fontSize: '0.8rem', color: '#0D1B3E', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Assigned Services ({getAssignedServices(hoveredRole.name).length})
            </h4>
          </div>
          
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
            {getAssignedServices(hoveredRole.name).map((service, idx) => (
              <span key={idx} style={{
                background: '#F0F7FF',
                color: '#1756AA',
                padding: '4px 8px',
                borderRadius: '6px',
                fontSize: '0.72rem',
                fontWeight: 700,
                border: '1px solid rgba(23, 86, 170, 0.08)'
              }}>
                {service}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ── ADD/EDIT MODAL (DRAWER STYLE) ── */}
      {isModalOpen && (
        <div className={styles.drawerOverlay} onClick={() => setIsModalOpen(false)}>
          <div className={styles.drawer} onClick={(e) => e.stopPropagation()} style={{ width: '450px', maxWidth: '95%', background: '#fff' }}>
            <div className={styles.drawerHeader} style={{ padding: '20px 25px', borderBottom: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(59, 130, 246, 0.1)', color: '#3B82F6' }}>
                  <FiUsers size={18} />
                </div>
                <h2 style={{ margin: 0, fontSize: '1.15rem', color: '#0F172A', fontWeight: 800 }}>{formData.id ? 'Edit Role' : 'Role Details'}</h2>
              </div>
              <button onClick={() => setIsModalOpen(false)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '32px', height: '32px', borderRadius: '50%', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#475569', cursor: 'pointer', transition: 'all 0.2s' }}>
                <FiX size={16} />
              </button>
            </div>

            <div className={styles.drawerBody} style={{ padding: '25px', overflowY: 'auto' }}>
              <form onSubmit={handleSave}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Role</label>
                      <input type="text" name="name" className={styles.inputControl} value={formData.name} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} required />
                    </div>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Prefix</label>
                      <input type="text" name="prefix" className={styles.inputControl} value={formData.prefix} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} required />
                    </div>
                  </div>

                  <div className={styles.formGroup}>
                    <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Type</label>
                    <select name="type" className={styles.inputControl} value={formData.type} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }}>
                      <option value="">Select Type</option>
                      <option value="Admin">Admin</option>
                      <option value="Retailer">Retailer</option>
                      <option value="Master Distributor">MASTER DISTRIBUTOR</option>
                      <option value="Distributor">DISTRIBUTOR</option>
                      <option value="Employee">Employee</option>
                      <option value="ATM">ATM</option>
                    </select>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>StartID</label>
                      <input type="number" name="startId" className={styles.inputControl} value={formData.startId} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} required />
                    </div>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Registration Count</label>
                      <input type="number" name="regCount" className={styles.inputControl} value={formData.regCount} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} required />
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Active</label>
                      <div style={{ background: '#F8FAFC', padding: '10px 14px', borderRadius: '10px', border: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', height: '42px' }}>
                        <input type="checkbox" checked={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.checked })} style={{ width: '18px', height: '18px', cursor: 'pointer' }} />
                      </div>
                    </div>
                    <div className={styles.formGroup}>
                      <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>OutSide</label>
                      <div style={{ background: '#F8FAFC', padding: '10px 14px', borderRadius: '10px', border: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', height: '42px' }}>
                        <input type="checkbox" checked={formData.outside} onChange={(e) => setFormData({ ...formData, outside: e.target.checked })} style={{ width: '18px', height: '18px', cursor: 'pointer' }} />
                      </div>
                    </div>
                  </div>

                  <div className={styles.formGroup}>
                    <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Price</label>
                    <input type="number" name="price" className={styles.inputControl} value={formData.price} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} required />
                  </div>

                  <div className={styles.formGroup}>
                    <label className={styles.label} style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Redirect Url</label>
                    <input type="text" name="redirectUrl" className={styles.inputControl} value={formData.redirectUrl} onChange={handleInputChange} style={{ borderRadius: '10px', padding: '10px 14px', border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#1E293B', fontSize: '0.9rem' }} />
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '15px', marginTop: '30px', paddingTop: '20px', borderTop: '1px solid #F1F5F9' }}>
                  <button type="button" style={{ padding: '12px 20px', background: '#F8FAFC', border: '1px solid #E2E8F0', color: '#475569', borderRadius: '10px', fontWeight: 700, cursor: 'pointer', transition: 'all 0.2s', flex: 1 }} onClick={() => setIsModalOpen(false)}>
                    Cancel
                  </button>
                  <button type="submit" style={{ padding: '12px 20px', background: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)', border: 'none', color: '#fff', borderRadius: '10px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', flex: 1.5, boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)', transition: 'all 0.2s' }}>
                    Save Role <FiCheck size={16} />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {showConfirmModal.isOpen && (
        <div className={styles.modalOverlay} style={{ zIndex: 3600 }}>
          <div className={styles.modalContainer} style={{ width: '380px', borderRadius: '16px', padding: '24px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <div style={{ width: '50px', height: '50px', background: '#FFF5F5', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E53E3E', marginBottom: '16px' }}>
                <FiTrash2 style={{ fontSize: '1.2rem' }} />
              </div>
              <h3 style={{ margin: '0 0 8px 0', fontSize: '1.1rem', color: '#0D1B3E' }}>Delete Role</h3>
              <p style={{ margin: '0 0 20px 0', fontSize: '0.85rem', color: '#718096', lineHeight: '1.4' }}>
                Are you sure you want to delete this role? This action cannot be undone.
              </p>
              <div style={{ display: 'flex', gap: '12px', width: '100%' }}>
                <button
                  onClick={() => setShowConfirmModal({ isOpen: false, id: null })}
                  style={{ flex: 1, padding: '10px', background: '#F1F5F9', border: 'none', borderRadius: '8px', color: '#4E6080', fontWeight: 600, cursor: 'pointer' }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleDelete}
                  style={{ flex: 1, padding: '10px', background: '#E53E3E', border: 'none', borderRadius: '8px', color: '#fff', fontWeight: 600, cursor: 'pointer' }}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoleManagement;
